## compute subtracks test
# positions = positions._append({
#                     "Name":'test_up',
#                     "Chromosome":"NC_014500.1",
#                     "Start": 4920000,
#                     "End":4921000,
#                     "Strand":1,
#                     "Track":0
#                 },ignore_index = True)
#                 positions = positions._append({
#                     "Name":'test_down',
#                     "Chromosome":"NC_014500.1",
#                     "Start":12000,
#                     "End":13000,
#                     "Strand":1,
#                     "Track":0
#                 },ignore_index = True)
#                 print(positions)
#                 print(bw_tracks.chroms())

#                 for subtrack in subtracks.keys():
#                     if subtrack == 40 or subtrack == 41:
#                         print(subtracks[subtrack])