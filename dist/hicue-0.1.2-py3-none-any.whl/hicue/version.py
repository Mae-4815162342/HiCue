from importlib.metadata import version

__version__ = version("hicue")
__format_version__ = 1