
def write_matrix():
    pass